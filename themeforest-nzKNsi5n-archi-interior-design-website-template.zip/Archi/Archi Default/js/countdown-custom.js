jQuery(document).ready(function() {
        $(function () {
            $('#defaultCountdown').countdown({until: new Date(2021, 03, 20, 8)}); // year, month, date, hour
        });
});		

